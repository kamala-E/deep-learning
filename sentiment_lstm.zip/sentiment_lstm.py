import numpy as np
from tensorflow.keras.datasets import imdb
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, LSTM, Dense
from sklearn.metrics import confusion_matrix, classification_report

# 1. Load Dataset
vocab_size = 10000  # top 10,000 common words
max_length = 200    # max words per review

(x_train, y_train), (x_test, y_test) = imdb.load_data(num_words=vocab_size)

# 2. Pad Sequences
x_train = pad_sequences(x_train, maxlen=max_length)
x_test = pad_sequences(x_test, maxlen=max_length)

# 3. Build LSTM Model
model = Sequential()
model.add(Embedding(input_dim=vocab_size, output_dim=64, input_length=max_length))
model.add(LSTM(64))
model.add(Dense(1, activation='sigmoid'))

# 4. Compile Model
model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])

# 5. Train Model
print("Training the model...")
model.fit(x_train, y_train, epochs=3, batch_size=128, validation_split=0.2)

# 6. Evaluate Model
loss, accuracy = model.evaluate(x_test, y_test)
print(f"\n✅ Test Accuracy: {accuracy * 100:.2f}%")

# 7. Confusion Matrix
y_pred = (model.predict(x_test) > 0.5).astype("int32")
print("\n🧾 Confusion Matrix:")
print(confusion_matrix(y_test, y_pred))
print("\n📊 Classification Report:")
print(classification_report(y_test, y_pred))

# 8. Test on Custom Input
word_index = imdb.get_word_index()
reverse_word_index = {value: key for key, value in word_index.items()}

def encode_text(text):
    words = text.lower().split()
    encoded = [word_index.get(word, 0) for word in words]
    return pad_sequences([encoded], maxlen=max_length)

def predict_sentiment(text):
    encoded_text = encode_text(text)
    prediction = model.predict(encoded_text)[0][0]
    sentiment = "Positive 😊" if prediction > 0.5 else "Negative 😞"
    print(f"Input: {text}\nPredicted Sentiment: {sentiment}\n")

# Sample Tests
predict_sentiment("I love this movie!")
predict_sentiment("The service was terrible.")
